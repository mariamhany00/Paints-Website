import React from 'react'
import { Col, Row } from 'react-bootstrap'
import storeittems from '../data/storeittems.json'
import StoreItem from './StoreItem'

function Store() {
  return (
<>
<h1>Store</h1>
<Row md={2} xs={1} lg={3} className='g-3 w-100 h-100' >
{storeittems.map((item)=>(
  <Col key={item.id}>
    <StoreItem {...item}
    />
  </Col>
))}
</Row>
</>
  )
}

export default Store