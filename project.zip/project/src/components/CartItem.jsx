import React from 'react';
import { Stack } from 'react-bootstrap';
import storeittems from '../data/storeittems.json'
import formatCurrency from './formatCurrency';
import { useShoppingCart } from '../context/ShoppingCartContext';
import { Button } from 'react-bootstrap';

function CartItem({ id, quantity }) {
    const { removeItem } = useShoppingCart();
    const item = storeittems.find((i) => i.id === id); // Corrected variable name
    if (!item) // Corrected null check
        return null;
  
    return (
        <Stack direction='horizontal' gap={2} className='d-flex align-items-center'>
            <img
                src={item.imgUrl}
                alt='cart-image'
                style={{ width: "125px", height: "75px", objectFit: "cover" }}
            />
            <div className='me-auto'>
                <div>
                    {item.name}{" "}
                    {quantity > 1 && (
                        <span className="text-muted" style={{ fontSize: "0.65rem" }}>
                            x{quantity}
                        </span>
                    )}
                </div>
                <div className="text-muted" style={{ fontSize: "0.75rem" }}>
                    {formatCurrency(item.price)} 
                </div>
                <div>{formatCurrency(item.price * quantity)}</div>
                <Button
        variant="outline-danger"
        size="sm"
        onClick={() => removeItem(item.id)}
      >
        &times;
      </Button>
            </div>
        </Stack>
    );
}

export default CartItem;
