import React from 'react';
import { Container, Nav, Navbar as Navbs, Button } from 'react-bootstrap';
import { NavLink } from 'react-router-dom'; // Import NavLink if you're using React Router
import { BsCart3 } from "react-icons/bs";
import { useShoppingCart } from '../context/ShoppingCartContext';

function Navbar() {
  const{openCart,cartQuantity }=useShoppingCart()
  return (
    <Navbs sticky='top' className='bg-white shadow-sm mb-3'  >
      <Container >
        <Nav className='me-auto'>
          <Nav.Link as={NavLink} to="/">Home </Nav.Link>
          <Nav.Link as={NavLink} to="/store">Store</Nav.Link>
          <Nav.Link as={NavLink} to="/about">About</Nav.Link>
        </Nav>
        <Button
          style={{ width: "45px", height: "40px", position: "relative" }}
          variant="outline-primary"
          className="rounded-circle"
          onClick={openCart}
        >
          <BsCart3 size={25} />
          <div className='rounded-circle bg-danger d-flex justify-content-center align-items-center' style={{position:"absolute",color:"white",width:"1.5rem",height:"1.5rem",bottom:0,right:0,transform:"translate(50%, -50%)"}}>
            {cartQuantity}
          </div>
        </Button>
      </Container>
    </Navbs>
  );
}

export default Navbar;

